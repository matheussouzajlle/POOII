package projeto.spotify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatheusApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatheusApplication.class, args);
	}

}

