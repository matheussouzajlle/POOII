package projeto.spotify;

import jakarta.persistence.*;

import java.util.Set;

@Entity
public class Artista {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;

    @OneToMany(mappedBy = "artista")
    private Set<Musica> musicas;

    // Getters e Setters
}
